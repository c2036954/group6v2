<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- ------style--------------- -->




    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            overflow-x: hidden;
        }
        body{
           font-family: sans-serif; 
        }
        .body{
            margin-top: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    .body h1{
        color: #575DD3;
        font-size: 35px;
    }
    .Register{
        border: 2px solid #9496C2;
        margin-top: 20px;
      width: 452px;
      height: 335px;
      padding: 10px;
        display: block;
    }
    .Register h2{
        text-align: center;
        color: #575DD3;
    }
 
    .Register .button{
      
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
       
      
    }
    .button button{
        width: 320px;
        height: 60px;
        background-color: #A6A4F0;
        border: 2px solid #817FEE;
        color: #fff;
        font-size: 20px;
      
        cursor: pointer;

        
    }
    form{
      padding: 24px 20px 20px 20px;
    }
    form label{
        color: #575DD3;
        font-size: 20px;
        font-weight: 600;
       
    }
    form input{
        outline: none;
        width: 243px;
        border: 2px solid #CFD1E4;
        height: 35px;
        margin-bottom: 0px;
        
    }
 
    </style>
</head>
<body>
    <div class="body">
    <!-- -----------header---------- -->
    <h1>Research Collaborative Engine</h1>
    <!-- --------------Register----------- -->
    <div class="Register">
        <h2>Registration</h2>
        <!-- ---------form------------ -->
        <form action="db.php" method="post">
            <label>Name</label>
      
            <div class="center">
            <input type="text" name="Username" placeholder="Username">

            
        </div>
        <!-- ----------------------------------- -->
        <label>E-mail</label>
      
        <div class="center">
        <input type="text" name="Email" placeholder="Email">
    </div>
    <!-- ---------------------------------------------- -->
    <label>Password</label>
    <div class="center">
        <input type="password" name="Password" placeholder="Password">
    </div>
        </form>
       
     
        <!-- --------button----------- -->
        <div class="button">
            <button>Register </button></a>

            
      
    </div>
</div>
<?php
$dsn = "mysql:host=localhost;dbname=users";
$dbusername = "root";
$dbpassword = "";



$Name = isset($_POST['Username']) ? $_POST['Username'] : '';
$Email = isset($_POST['Email']) ? $_POST['Email'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';

echo $Name;


$sql = "INSERT INTO users (Name, Email, Password,) VALUES ('$Name', '$Email', '$Password', );";




?>
</body>
</html>