<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Publications </title>
    <!-- ------style--------------- -->

    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            overflow-x: hidden;
        }
        body{
           font-family: sans-serif; 
        }
        .body{
            margin-top: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    .body h1{
        color: #575DD3;
        font-size: 35px;
    }
    .Collaboration{
        border: 2px solid #9496C2;
        margin-top: 20px;
      width: 852px;
      height: 665px;
      padding: 10px;
        display: block;
    }
    .Collaboration h2{
        text-align: center;
        color: #575DD3;
    }
 
    .Collaboration .button{
      
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
       
      
    }
    .button button{
        width: 320px;
        height: 60px;
        background-color: #A6A4F0;
        border: 2px solid #817FEE;
        color: #fff;
        font-size: 20px;
      margin-top: 200px;
        cursor: pointer;

        
    }
.vector_space{
    border: 2px solid #CFD1E4;
    padding: 80px 0px;
display: flex;
align-items: center;
justify-content: center;
    margin: 10px;
}
 .vector_space p{
position: absolute;
margin-bottom: -30px;
color: #575DD3;
font-weight: 600;
font-size: 18px;

 }
 .section{
    text-align: center;
    margin-top:20px;
    padding: 10px;
 }
 .section p{
    border: 1px solid #A6A4F0;
    padding: 7px;
    color: #575DD3; font-weight: 600;
 }
    </style>
<?php
$dsn = "mysql:host=localhost;dbname=users";
$dbusername = "root";
$dbpassword = "";

try {
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection Failed: " . $e->getMessage();
}

$sql = "SELECT * FROM PUBLICATIONS";
$stmnt = $pdo->prepare($sql);
$stmnt->execute();
$rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Publications</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <div class="body">
        <h1>Research Collaborative Engine</h1>
        <div class="Collaboration">
            <h2>Staff Publications</h2>
            <div class="section">
                <?php
                if ($rows) {
                    foreach ($rows as $row) {
                        echo "<p style='color: #575DD3;'>" . $row["Author"] . " - " . $row["Title"] . " - " . $row["Link"] . " - " . $row["Keyword"] . " - " . $row["Year"] . "</p>";
                    }
                } else {
                    echo "0 results";
                }
                ?>
                
            </div>
           
            
        </div>
        <div class="button">
                <button>Contact</button>
                <a href="main_page.php"><button>Go Back</button></a>
            </div>
    </div>
</body>
</html>
