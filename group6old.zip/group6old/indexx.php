<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaboration Network</title>
</head>
<body>
    <h1>Research Collaborative Engine</h1>
    
    <div id="collaborations"></div>

    <button id="fetchButton">Fetch Collaborations</button>

    <script>
        document.getElementById("fetchButton").addEventListener("click", function() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_collaborations.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var collaborations = JSON.parse(xhr.responseText);
                        displayCollaborations(collaborations);
                    } else {
                        console.error("Failed to fetch collaborations");
                    }
                }
            };
            xhr.send();
        });

        function displayCollaborations(collaborations) {
            var collaborationsContainer = document.getElementById("collaborations");
            collaborationsContainer.innerHTML = ""; // Clear previous content

            if (collaborations.length === 0) {
                collaborationsContainer.textContent = "No collaborations found.";
                return;
            }

            var ul = document.createElement("ul");
            collaborations.forEach(function(collaboration) {
                var li = document.createElement("li");
                li.textContent = collaboration.vector1_name + " and " + collaboration.vector2_name + " - Cosine Similarity: " + collaboration.cosine_similarity;
                ul.appendChild(li);
            });
            collaborationsContainer.appendChild(ul);
        }
    </script>
</body>