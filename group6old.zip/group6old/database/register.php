<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["Username"];
    $password = $_POST["Password"];
    $email = $_POST["Email"];

    try {
        require_once "db.php";  // Make sure to include the correct database connection file

        $query = "INSERT INTO users (Username, Password, Email) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($query);

        // Hash the password before storing it in the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt->execute([$username, $hashed_password, $email]);

        $pdo = null;
        $stmt = null;

        header("Location: ../register.html");
        exit();  // Use exit() instead of die() to terminate the script

    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    header("Location: ../register.html");
    exit();  // Use exit() instead of die() to terminate the script
}
// End of fixed PHP code
