

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaboration Network</title>
    <!-- ------style--------------- -->

    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            overflow-x: hidden;
        }
        body{
           font-family: sans-serif; 
        }
        .body{
            margin-top: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    .body h1{
        color: #575DD3;
        font-size: 35px;
    }
    .Collaboration{
        border: 2px solid #9496C2;
        margin-top: 20px;
      width: 452px;
      height: 165px;
      padding: 10px;
        display: block;
    }
    .Collaboration h2{
        text-align: center;
        color: #575DD3;
    }
 
    .Collaboration .button{
      
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
       
      
    }
    .button button{
        width: 320px;
        height: 60px;
        background-color: #A6A4F0;
        border: 2px solid #817FEE;
        color: #fff;
        font-size: 20px;
      margin-top: 20px;
        cursor: pointer;

        
    }

    </style>
    
</head>
<body>
    <div class="body">
    <!-- -----------header---------- -->
    <h1>Research Collaborative Engine</h1>
    <!-- --------------Collaboration----------- -->
    <div class="">
        <h2><p style='color: #575DD3;'>Recomended Collaborations</h2>
        <!-- ---------form------------ -->
      
        <!-- --------button----------- -->
        <div class="button">
     
            <a href="collaboration_network.php"><button>Go Back</button></a>
            
      
    </div>
</div>
</body>
</html

<?php
$dsn = "mysql:host=localhost;dbname=users";
$dbusername = "root";
$dbpassword = "";



try {
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection Failed: " . $e->getMessage();
}
$sql = "
SELECT 
    A.Name AS vector1_id, 
    B.Name AS vector2_id, 
    (A.NLP * B.NLP + A.NS * B.NS + A.RS * B.RS + A.CG * B.CG + A.CV * B.CV + A.GN * B.GN + A.KL * B.KL) /
    (SQRT(A.NLP * A.NLP + A.NS * A.NS + A.RS * A.RS + A.CG * A.CG + A.CV * A.CV + A.GN * A.GN + A.KL * A.KL) *
    SQRT(B.NLP * B.NLP + B.NS * B.NS + B.RS * B.RS + B.CG * B.CG + B.CV * B.CV + B.GN * B.GN + B.KL * B.KL)) AS cosine_similarity
FROM 
    Users A
CROSS JOIN 
    Users B
WHERE 
    A.Name <> B.Name";
$stmnt = $pdo->prepare($sql);

$stmnt->execute();

$rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);



if ($rows) 
    foreach ($rows as $row) {
        echo "<p style='color: #575DD3;'>" . $row["vector1_id"];
        echo " and ";
        echo $row["vector2_id"];
        echo " = ";
        echo $row["cosine_similarity"];
    }
    

    
else {
    echo "0 results";
}


?>

