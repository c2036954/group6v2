
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password for the root user
$database = "users";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Form data
$Name = isset($_POST['Username']) ? $_POST['Username'] : '';
$Email = isset($_POST['Email']) ? $_POST['Email'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';

// SQL query to insert data into the database
$sql = "INSERT INTO register (Name, Email, Password) VALUES (:Name, :Email, :Password)";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':Name', $Name);
$stmt->bindParam(':Email', $Email);
$stmt->bindParam(':Password', $Password);

try {
    $stmt->execute();
    echo "Registration successful";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

