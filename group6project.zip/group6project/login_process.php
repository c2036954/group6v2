<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "users";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Form data
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// SQL query to check user credentials
$sql = "SELECT * FROM register WHERE Name = :username AND Password = :password";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);

try {
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        // User found, redirect to main page or wherever you want
        header("Location: sucess.php");
        exit();
    } else {
        // Invalid credentials, redirect back to login page
        header("Location: 404.php");
        exit();
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
