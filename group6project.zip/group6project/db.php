

<?php
$dsn = "mysql:host=localhost;dbname=users";
$dbusername = "root";
$dbpassword = "";



try {
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection Failed: " . $e->getMessage();
}
$sql = "
SELECT 
    A.Name AS vector1_name, 
    B.Name AS vector2_name, 
    (A.NLP * B.NLP + A.NS * B.NS + A.RS * B.RS + A.CG * B.CG + A.CV * B.CV + A.GN * B.GN + A.KL * B.KL) /
    (SQRT(A.NLP * A.NLP + A.NS * A.NS + A.RS * A.RS + A.CG * A.CG + A.CV * A.CV + A.GN * A.GN + A.KL * A.KL) *
    SQRT(B.NLP * B.NLP + B.NS * B.NS + B.RS * B.RS + B.CG * B.CG + B.CV * B.CV + B.GN * B.GN + B.KL * B.KL)) AS cosine_similarity
FROM 
    Users A
CROSS JOIN 
    Users B
WHERE 
    A.Name <> B.Name
    AND (A.NLP * B.NLP + A.NS * B.NS + A.RS * B.RS + A.CG * B.CG + A.CV * B.CV + A.GN * B.GN + A.KL * B.KL) /
        (SQRT(A.NLP * A.NLP + A.NS * A.NS + A.RS * A.RS + A.CG * A.CG + A.CV * A.CV + A.GN * A.GN + A.KL * A.KL) *
        SQRT(B.NLP * B.NLP + B.NS * B.NS + B.RS * B.RS + B.CG * B.CG + B.CV * B.CV + B.GN * B.GN + B.KL * B.KL)) >= 0.6";
$stmnt = $pdo->prepare($sql);

$stmnt->execute();

$rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);



if ($rows) 
    foreach ($rows as $row) {
        echo "<p style='color: #575DD3;'>" . $row["vector1_name"];
        echo $row["vector2_name"];
        echo $row["cosine_similarity"];
    }
    

    
else {
    echo "0 results";
}


?>

