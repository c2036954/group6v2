<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- ------style--------------- -->

    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            overflow-x: hidden;
        }
        body{
           font-family: sans-serif; 
        }
        .body{
            margin-top: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    .body h1{
        color: #575DD3;
        font-size: 35px;
    }
    .login{
        border: 2px solid #9496C2;
        margin-top: 20px;
      width: 452px;
      height: 505px;
      padding: 10px;
        display: block;
    }
    .login h2{
        text-align: center;
        color: #575DD3;
    }
 
    .login .button{
       margin-top: 30px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
       
      
    }
    .button button{
        width: 400px;
        height: 60px;
        background-color: #A6A4F0;
        border: 2px solid #817FEE;
        color: #fff;
        font-size: 20px;
        margin-bottom: 10px;
        cursor: pointer;

        
    }
    form{
      padding: 24px 20px 20px 20px;
    }
    form label{
        color: #575DD3;
        font-size: 24px;
        font-weight: 600;
        padding-left: 75px;
    }
    form input{
        outline: none;
        width: 243px;
        border: 2px solid #CFD1E4;
        height: 35px;
        margin-bottom: 20px;
        
    }
    .center{
        display: flex;
      
       justify-content: center;
       align-items: center;
    }
    </style>
</head>
<body>
    <div class="body">
    <!-- -----------header---------- -->
    <h1>Research Collaborative Engine</h1>
    <!-- --------------login----------- -->
    <div class="login">
        <h2>Login</h2>
        <!-- ---------form------------ -->
        <form action="login_process.php" method="post">
            <label>Username</label>
      
            <div class="center">
            <input type="text" name="username" required>
        </div>
        <!-- ----------------------------------- -->
        <label>Password</label>
      
        <div class="center">
        <input type="password" name="password" required>
    </div>
       
     
        <!-- --------button----------- -->
        <div class="button">
        <button type="submit">login</button>
                    <button type="button" onclick="window.location.href='main_page.html';">Login as Admin</button>
                    <button type="button" onclick="window.location.href='register.php';">Create new account</button>
                </div>
                </form>
       
</div>
</body>
</html